import os

#Абсолютный путь до файла
path = os.getcwd()
#print(path)

#можно вызвать любую команду, которая доступна в терминале
#os.system('ping google.com')

#make a file
#os.system('echo off > file1.txt')
#os.system('echo off > file2.txt')
#os.system('echo off > file3.txt')

#make a directory
#os.makedirs('first_dir/tra/ta/ta/and_more')
#os.mkdir('second_dir')

#replase / rename
#os.replace(
#    path+'/file3.txt',
#    path+'/first_dir/tra/ta/ta/and_more/file3.txt')

#содержимое папки
#print(os.listdir(path))

#содержимое папки в словаре
#print(os.scandir(path))

#for item in os.scandir(path):
#    if item.is_file():
#        print(item.name, ' <--file')
#    if item.is_dir():
#        print(item.name, ' <--directory')

#содержимое папки в глубину
#for item in os.walk(path):
#    print(item)

#del file
#os.remove(
#    path+'/first_dir/tra/ta/ta/and_more/file3.txt')

#del dir
#os.rmdir(path+'/second_dir')
#os.removedirs(path+'/first_dir/tra/ta/ta/and_more/')