import sqlite3
import datetime

#для хранения дат
def get_timestamp(y,m,d):
    return datetime.datetime.timestamp(datetime.datetime(y,m,d))

#для вывода дат
def get_date(tmstmp):
    return datetime.datetime.fromtimestamp(tmstmp).date()

#подключение к БД
#with sqlite3.connect('cmdb.db') as db:
    #оздание курсора БД
#    cursor = db.cursor()

    #Запрос к БД на создание таблицы      имя таблицы(поля таблицы)
#    query = """ CREATE TABLE IF NOT EXISTS expenses (id INTEGER, name TEXT) """
#    cursor.execute(query)

    #Запрос к БД на создание записи в таблице (поля таблицы) + значения полей
#    query1 = """ INSERT INTO expenses (id, name) VALUES (1, 'Коммуналка') """
#    query2 = """ INSERT INTO expenses (name, id) VALUES ('Бензин', 2) """
#    query3 = """ INSERT INTO expenses VALUES (3, 'Интернет') """

#    cursor.execute(query1)
#    cursor.execute(query2)
#    cursor.execute(query3)
# кортеж добавляемых данных
insert_payments= [
    (1,120, get_timestamp(2020, 9, 1), 1),
    (2,12, get_timestamp(2020, 9, 1), 3),
    (3,20, get_timestamp(2020, 9, 1), 2),
    (4,20, get_timestamp(2020, 9, 2), 2),
    (5,20, get_timestamp(2020, 9, 3), 2),
    (6,20, get_timestamp(2020, 9, 4), 2),
    (7,20, get_timestamp(2020, 9, 5), 2),
]

with sqlite3.connect('cmdb.db') as db:
    cursor = db.cursor()

#    query = """ CREATE TABLE IF NOT EXISTS payments (
#        id INTEGER,
#        amount REAL,
#        payment_date INTEGER,
#        expense_id INTEGER
#    )"""

#    query = """ INSERT INTO payments (id, amount, payment_date, expense_id)
#        VALUES (?, ?, ?, ?) """

# вывод данных из БД
    # все подряд
    query = """ SELECT * FROM payments"""
    #только бензин
    query = """ SELECT amount, payment_date, name FROM payments JOIN expenses
        ON expenses.id = payments.expense_id 
        #WHERE expense_id=2
        WHERE (payment_day > %(from)d)
        AND (payment_day < %(to)d)
        """ % {'from': get_timestamp(2009,9,1), 'to': get_timestamp(2009,9,5)}
    cursor.execute(query)

    sum = 0
    for res in cursor:
        sum += res[0]
        print(res[0], get_date(res[1]), res[2])
    print('Total:', sum)
#   cursor.executemany(query,insert_payments)
#    db.commit()
#    print(cursor.rowcount, 'строк добавлено')



    #commit изменений в базу
    #db.commit()

#закрытие сеанса с БД
#db.close()